# ============================================================
# 1. CONFIGURATION
# ============================================================

OUTPUT_FOLDER_NAME = "FileTreeGen"   # Sub-folder created on the Desktop
MAX_NAME_LENGTH    = 50              # Characters before a node label is truncated

# Graphviz node appearance
NODE_FONT     = "Consolas"  # Font inside each node box
NODE_FONTSIZE = "11"        # Font size (pt) for node labels
GRAPH_DPI     = "150"       # Render resolution (higher = larger / sharper SVG)
GRAPH_RANKDIR = "LR"        # "LR" = left-to-right tree  |  "TB" = top-to-bottom

# File leaf nodes use a clean white fill; depth is shown via their border colour.
FILE_FILL = "#FFFFFF"

# 10-level depth palette — each tree level gets a distinct pastel fill.
# Cycles back to level 0 once the tree goes deeper than 10 levels.
# Each entry: fill (node background), font (dark readable text), border (outline).
DEPTH_COLORS = [
    {"fill": "#DCEBFF", "font": "#1A3560", "border": "#5A90D0"},  # 0  Light Blue
    {"fill": "#DDF5E3", "font": "#1A4828", "border": "#50A060"},  # 1  Mint
    {"fill": "#FFF1CC", "font": "#4A3800", "border": "#C09820"},  # 2  Soft Yellow
    {"fill": "#FCE1E4", "font": "#4A1525", "border": "#C05068"},  # 3  Soft Pink
    {"fill": "#E8DEFF", "font": "#2A1858", "border": "#7060C0"},  # 4  Lavender
    {"fill": "#DDF4F4", "font": "#0A3838", "border": "#409898"},  # 5  Aqua
    {"fill": "#FFE4CC", "font": "#4A2800", "border": "#C07838"},  # 6  Peach
    {"fill": "#E5E5F5", "font": "#1A1A48", "border": "#5858A0"},  # 7  Periwinkle
    {"fill": "#E6F4D7", "font": "#1A3808", "border": "#589828"},  # 8  Light Green
    {"fill": "#F5E1F5", "font": "#380838", "border": "#9848A0"},  # 9  Soft Purple
]


# ============================================================
# 2. IMPORTS
# ============================================================

import os
import sys
import time
from pathlib import Path
from datetime import datetime

# graphviz is the only external dependency.
# IMPORTANT: Two separate things are needed on Windows:
#   1. pip install graphviz          <- Python wrapper package
#   2. Graphviz application (dot.exe) from https://graphviz.org/download/
#      During installation, tick "Add Graphviz to the system PATH".
#      Then restart your terminal and verify with: dot -V
try:
    import graphviz
except ImportError:
    print("\n[ERROR] The 'graphviz' Python package is not installed.")
    print("Fix:  pip install graphviz\n")
    sys.exit(1)

# ============================================================
# 3. PATH / OUTPUT SETUP
# ============================================================

def get_output_directory() -> Path:
    """
    Locate the current Windows user's Desktop dynamically and return
    the full path to the FileTreeGen output sub-folder inside it.
    Uses USERPROFILE (reliable on all modern Windows versions) and falls
    back to Path.home() so it works regardless of username or drive.
    """
    home    = Path(os.environ.get("USERPROFILE", str(Path.home())))
    desktop = home / "Desktop"

    if not desktop.exists():
        desktop = Path.home() / "Desktop"   # secondary fallback

    output_dir = desktop / OUTPUT_FOLDER_NAME
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir


def build_output_stem(root_name: str, output_dir: Path) -> Path:
    """
    Return a unique file stem (no extension) like:
        Desktop\\FileTreeGen\\MyProject_20260925_1501
    graphviz's render() appends '.svg' automatically.
    A counter suffix prevents accidental overwrites within the same minute.
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    base      = f"{root_name}_{timestamp}"

    counter = 1
    while (output_dir / f"{base}.svg").exists():
        base    = f"{root_name}_{timestamp}_{counter}"
        counter += 1

    return output_dir / base


# ============================================================
# 4. DIRECTORY SCANNING
# ============================================================

def scan_directory(root_path: Path) -> dict:
    """
    Recursively walk the filesystem from root_path and return a nested
    dictionary that mirrors the real folder/file structure.

    Schema of each node dict:
        {
            "name":     str,            # the file or folder name
            "type":     "dir"/"file",
            "children": [...]           # list of child nodes (dirs only)
        }

    Folders are listed before files (alphabetically within each group).
    PermissionError is caught per directory so one inaccessible folder
    does not abort the entire scan.
    """
    def build_node(path: Path) -> dict:
        node = {
            "name": path.name,
            "type": "dir" if path.is_dir() else "file"
        }

        if path.is_dir():
            node["children"] = []
            try:
                # Sort: subdirectories first, then files -- both alphabetically.
                entries = sorted(
                    path.iterdir(),
                    key=lambda p: (0 if p.is_dir() else 1, p.name.lower())
                )
                for entry in entries:
                    node["children"].append(build_node(entry))
            except PermissionError:
                print(f"  Warning: Could not access: {path}")

        return node

    return build_node(root_path)




def count_nodes(tree: dict):
    """Walk the full tree and return (folder_count, file_count)."""
    folders = 0
    files   = 0

    def walk(node):
        nonlocal folders, files
        if node["type"] == "dir":
            folders += 1
            for child in node.get("children", []):
                walk(child)
        else:
            files += 1

    walk(tree)
    # Subtract 1 for the root -- it is shown as the entry point, not a child.
    return max(0, folders - 1), files

# ============================================================
# 5. GRAPHVIZ GRAPH BUILDING
# ============================================================

def truncate(name: str) -> str:
    """Shorten extremely long names so node boxes stay compact."""
    if len(name) <= MAX_NAME_LENGTH:
        return name
    return name[:MAX_NAME_LENGTH - 3] + "..."


def build_graph(tree: dict) -> graphviz.Digraph:
    """
    Convert the nested tree dictionary into a Graphviz Digraph.

    Every folder and file becomes a node.
    Every parent -> child relationship becomes a directed edge.

    Depth colouring: each level of the tree is assigned a distinct pastel
    colour from DEPTH_COLORS (10 levels, then cycles). Folder nodes get the
    full pastel fill; file leaf nodes use white fill so they are visually
    distinct, while still inheriting the border and font of their depth level.
    Edges are coloured to match the parent node's border colour.

    Node IDs are plain integers (as strings) so that special characters
    in filenames (spaces, dots, brackets, etc.) never break DOT syntax.
    """
    # Digraph = directed graph; arrows flow parent -> child.
    dot = graphviz.Digraph(name="FolderSco", comment="Generated by FolderSco")

    # ---- Global graph attributes ----------------------------------------
    dot.attr(
        rankdir = GRAPH_RANKDIR,   # overall layout direction
        dpi     = GRAPH_DPI,
        bgcolor = "#F0F2F5",       # light neutral background — pastels read well on it
        pad     = "0.5",
        nodesep = "0.3",           # gap between sibling nodes (same rank)
        ranksep = "0.6",           # gap between parent and child ranks
    )

    # ---- Default node style (overridden per node below) -----------------
    dot.attr("node",
        shape    = "box",
        style    = "filled,rounded",
        fontname = NODE_FONT,
        fontsize = NODE_FONTSIZE,
        margin   = "0.15,0.08",
    )

    # ---- Default edge style (colour overridden per edge below) ----------
    dot.attr("edge",
        arrowsize = "0.7",
        penwidth  = "1.0",
    )

    # Counter provides unique IDs without any dependency on the file name.
    id_counter = [0]

    def add_nodes(node: dict, parent_id, depth: int):
        """
        Recursively add each node and its edge to the Digraph.
        depth selects which palette entry to use; cycles every 10 levels.
        """
        node_id       = str(id_counter[0])
        id_counter[0] += 1
        label         = truncate(node["name"])

        # Pick the colour set for this depth level (cycles after 10).
        palette = DEPTH_COLORS[depth % len(DEPTH_COLORS)]

        if node["type"] == "dir":
            # Folder — solid pastel fill from the depth palette.
            dot.node(
                node_id,
                label     = f"[D]  {label}",
                fillcolor = palette["fill"],
                fontcolor = palette["font"],
                color     = palette["border"],
                penwidth  = "1.8",
            )
        else:
            # File — white fill keeps leaf nodes visually distinct from folders.
            # Border and font colour still come from the depth palette so the
            # hierarchy grouping stays clear.
            dot.node(
                node_id,
                label     = f"[F]  {label}",
                fillcolor = FILE_FILL,
                fontcolor = palette["font"],
                color     = palette["border"],
                penwidth  = "1.0",
            )

        # Edge coloured by the parent depth's border colour.
        if parent_id is not None:
            parent_palette = DEPTH_COLORS[(depth - 1) % len(DEPTH_COLORS)]
            dot.edge(
                parent_id,
                node_id,
                color    = parent_palette["border"],
                penwidth = "1.2",
            )

        # Recurse into children at the next depth level.
        for child in node.get("children", []):
            add_nodes(child, node_id, depth + 1)

    add_nodes(tree, None, 0)
    return dot

# ============================================================
# 6. IMAGE GENERATION  (Graphviz render)
# ============================================================

def check_graphviz_executable() -> bool:
    """
    Confirm that dot.exe is accessible before entering the scan loop.
    If missing, print a step-by-step Windows installation guide and
    return False so the program exits cleanly rather than crashing mid-run.
    """
    try:
        graphviz.version()   # internally calls: dot -V
        return True
    except graphviz.ExecutableNotFound:
        print()
        print("=" * 60)
        print("  ERROR: Graphviz executable (dot.exe) not found.")
        print()
        print("  The Python 'graphviz' package is installed, but the")
        print("  Graphviz application (dot.exe) must be installed too.")
        print()
        print("  How to install Graphviz on Windows:")
        print()
        print("  1. Go to:  https://graphviz.org/download/")
        print("     Download the Windows .exe installer.")
        print()
        print("  2. Run the installer.")
        print("     On the 'Additional Tasks' screen, tick:")
        print("     'Add Graphviz to the system PATH for all users'")
        print("     (or 'for current user')")
        print()
        print("  3. Close and reopen your terminal / command prompt.")
        print()
        print("  4. Confirm it works:  dot -V")
        print()
        print("  Then run FolderSco again.")
        print("=" * 60)
        print()
        return False


def render_graph(dot: graphviz.Digraph, output_stem: Path) -> Path:
    """
    Write the DOT source to disk, call dot.exe to render it as an SVG,
    then clean up the intermediate .gv source file.
    SVG is vector-based — it scales to any size without loss of quality.
    Returns the final .svg Path.
    """
    # dot.render() saves <stem>.gv, runs dot, produces <stem>.svg.
    # cleanup=True removes the .gv after rendering -- only the SVG is kept.
    dot.render(
        filename = str(output_stem),
        format   = "svg",
        engine   = "dot",
        cleanup  = True,
    )
    return output_stem.parent / (output_stem.name + ".svg")


# ============================================================
# 7. CORE SCAN PIPELINE
# ============================================================

def scan_one(folder_path: Path):
    """
    Run the complete pipeline for one folder path:
      validate -> scan -> build graph -> render PNG -> report

    Returns the PNG Path on success, or None if anything fails.
    Lives in its own function so the main() loop stays readable.
    """
    # ---- Validate the input -----------------------------------------------
    if not folder_path.exists():
        print()
        print("X  The specified path does not exist.")
        return None

    if not folder_path.is_dir():
        print()
        print("X  Please provide a folder path, not a file.")
        return None

    print()

    # ---- Scan the filesystem ----------------------------------------------
    print("Scanning folder...")
    start_time = time.time()

    tree                     = scan_directory(folder_path)
    folder_count, file_count = count_nodes(tree)

    print(f"  Folders found : {folder_count}")
    print(f"  Files found   : {file_count}")
    print()

    # ---- Build the Graphviz graph -----------------------------------------
    print("Building graph...")
    dot = build_graph(tree)

    # ---- Determine the output file path -----------------------------------
    output_dir  = get_output_directory()
    output_stem = build_output_stem(folder_path.name, output_dir)

    # ---- Render to PNG ----------------------------------------------------
    print("Rendering SVG via Graphviz dot...")
    try:
        png_path = render_graph(dot, output_stem)
    except graphviz.ExecutableNotFound:
        # dot.exe disappeared between the preflight check and render call.
        check_graphviz_executable()
        return None
    except Exception as exc:
        print(f"\nX  Graphviz rendering failed: {exc}")
        return None

    elapsed = time.time() - start_time

    # ---- Report success ---------------------------------------------------
    print()
    print(f"Done. ({elapsed:.2f}s)")
    print()
    print("Output:")
    print(f"  {png_path}")
    print()

    return png_path

# ============================================================
# 8. MAIN PROGRAM
# ============================================================

def main():
    # ---- Banner (shown once on startup) -----------------------------------
    print()
    print("=" * 44)
    print("              FOLDERSCO")
    print("       Folder Structure Visualizer")
    print("=" * 44)

    # ---- Preflight check: dot.exe must be on PATH before we loop ----------
    if not check_graphviz_executable():
        sys.exit(1)

    # ---- Main loop: keep scanning until the user exits --------------------
    while True:
        print()
        print("Enter folder path  (or type 'exit' to quit):")
        raw = input("> ").strip()

        # Allow quitting directly from the path prompt.
        if raw.lower() in ("exit", "quit", "q"):
            print()
            print("Goodbye!")
            print()
            break

        # Strip surrounding quotes (Windows adds them on drag-and-drop).
        raw = raw.strip('"').strip("'")

        if not raw:
            print("  (No path entered -- please try again.)")
            continue

        # Run the pipeline for this path.
        scan_one(Path(raw))

        # ---- After each run: continue or exit? ----------------------------
        print("-" * 44)
        print("  [1]  Scan another folder")
        print("  [2]  Exit")
        print("-" * 44)

        choice = input("> ").strip()

        if choice in ("2", "exit", "quit", "q"):
            print()
            print("Goodbye!")
            print()
            break
        # Pressing 1 or Enter loops back to the top automatically.


if __name__ == "__main__":
    main()
