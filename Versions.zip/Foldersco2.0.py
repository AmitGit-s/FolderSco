#!/usr/bin/env python3
"""
FolderSco 2.0  —  Folder Structure Visualizer (GUI Edition)
============================================================
Built on the same scanning and Graphviz engine as foldersco.py (Proto 1).

What is new in 2.0:
  • Full tkinter GUI dashboard
  • Folder input via paste, Browse dialog, or drag-and-drop
  • Output format choice: SVG / PNG / PDF / DOT
  • Output location + custom or auto filename
  • Threaded generation — UI stays responsive (no "Not Responding")
  • Live progress monitor: files scanned, folders scanned, elapsed time,
    current stage, indeterminate progress bar
  • Completion panel: summary stats + Open File / Open Folder / New Scan

Requirements (same as Proto 1):
  pip install graphviz
  Graphviz application (dot.exe) from https://graphviz.org/download/

Optional (drag-and-drop support):
  pip install tkinterdnd2
"""

# ============================================================
# 1. CONFIGURATION  (identical to Proto 1)
# ============================================================

OUTPUT_FOLDER_NAME = "FileTreeGen"   # Default output sub-folder on Desktop
MAX_NAME_LENGTH    = 50              # Max characters before a node label is truncated

# Graphviz node appearance
NODE_FONT     = "Consolas"
NODE_FONTSIZE = "11"
GRAPH_DPI     = "150"
GRAPH_RANKDIR = "LR"   # "LR" = left-to-right  |  "TB" = top-to-bottom

# File leaf nodes use white fill; depth colour shows via border/font.
FILE_FILL = "#FFFFFF"

# 10-level depth palette — cycles back to level 0 beyond depth 9.
DEPTH_COLORS = [
    {"fill": "#DCEBFF", "font": "#1A3560", "border": "#5A90D0"},  # 0  Light Blue
    {"fill": "#DDF5E3", "font": "#1A4828", "border": "#50A060"},  # 1  Mint
    {"fill": "#FFF1CC", "font": "#4A3800", "border": "#C09820"},  # 2  Soft Yellow
    {"fill": "#FCE1E4", "font": "#4A1525", "border": "#C05068"},  # 3  Soft Pink
    {"fill": "#E8DEFF", "font": "#2A1858", "border": "#7060C0"},  # 4  Lavender
    {"fill": "#DDF4F4", "font": "#0A3838", "border": "#409898"},  # 5  Aqua
    {"fill": "#FFE4CC", "font": "#4A2800", "border": "#C07838"},  # 6  Peach
    {"fill": "#E5E5F5", "font": "#1A1A48", "border": "#5858A0"},  # 7  Periwinkle
    {"fill": "#E6F4D7", "font": "#1A3808", "border": "#589828"},  # 8  Light Green
    {"fill": "#F5E1F5", "font": "#380838", "border": "#9848A0"},  # 9  Soft Purple
]

# ============================================================
# 2. IMPORTS
# ============================================================

import os
import sys
import time
import threading
from pathlib import Path
from datetime import datetime

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# Optional: drag-and-drop support via tkinterdnd2 (pip install tkinterdnd2)
try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
    HAS_DND = True
except ImportError:
    HAS_DND = False

# Graphviz Python package — required
try:
    import graphviz
except ImportError:
    # Show an error popup before the main window opens
    _root = tk.Tk()
    _root.withdraw()
    messagebox.showerror(
        "Missing Dependency",
        "The 'graphviz' Python package is not installed.\n\n"
        "Fix:  pip install graphviz\n\n"
        "Also ensure the Graphviz application (dot.exe) is installed:\n"
        "https://graphviz.org/download/"
    )
    sys.exit(1)

# ============================================================
# 3. BACKEND ENGINE  (same logic as Proto 1, minimal additions)
# ============================================================

def get_output_directory() -> Path:
    """
    Locate the current Windows user's Desktop dynamically and return
    the path to the FileTreeGen output sub-folder inside it.
    """
    home    = Path(os.environ.get("USERPROFILE", str(Path.home())))
    desktop = home / "Desktop"
    if not desktop.exists():
        desktop = Path.home() / "Desktop"
    output_dir = desktop / OUTPUT_FOLDER_NAME
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir


def build_output_stem(root_name: str, output_dir: Path,
                      fmt: str, custom_name: str = "") -> Path:
    """
    Return a unique Path stem (no extension) for the output file.
    Uses a custom name if provided, otherwise auto-generates one.
    """
    ext = fmt.lower()

    if custom_name.strip():
        base = custom_name.strip()
        # Strip any extension the user may have typed
        for e in (".png", ".svg", ".pdf", ".dot", ".gv"):
            if base.lower().endswith(e):
                base = base[: -len(e)]
    else:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M")
        base = f"{root_name}_{timestamp}"

    # Ensure uniqueness within the same minute
    stem    = base
    counter = 1
    while (output_dir / f"{stem}.{ext}").exists():
        stem    = f"{base}_{counter}"
        counter += 1

    return output_dir / stem


def scan_directory(root_path: Path, on_progress=None) -> dict:
    """
    Recursively walk root_path and return a nested dict tree.

    Identical to Proto 1, with one addition:
      on_progress(node_type: str) — optional callback called for every
      node found ('dir' or 'file'). Used by the GUI to show live counts
      without altering the core scanning logic.

    PermissionError is caught per directory — one locked folder does
    not abort the whole scan.
    """
    def build_node(path: Path) -> dict:
        node = {
            "name": path.name,
            "type": "dir" if path.is_dir() else "file",
        }

        if path.is_dir():
            node["children"] = []
            if on_progress:
                on_progress("dir")
            try:
                entries = sorted(
                    path.iterdir(),
                    key=lambda p: (0 if p.is_dir() else 1, p.name.lower()),
                )
                for entry in entries:
                    node["children"].append(build_node(entry))
            except PermissionError:
                pass   # Skip inaccessible folders silently in GUI mode
        else:
            if on_progress:
                on_progress("file")

        return node

    return build_node(root_path)


def count_nodes(tree: dict):
    """Return (folder_count, file_count) for the full tree."""
    folders = 0
    files   = 0

    def walk(node):
        nonlocal folders, files
        if node["type"] == "dir":
            folders += 1
            for child in node.get("children", []):
                walk(child)
        else:
            files += 1

    walk(tree)
    return max(0, folders - 1), files


def truncate(name: str) -> str:
    """Shorten a long filename so node boxes stay compact."""
    if len(name) <= MAX_NAME_LENGTH:
        return name
    return name[: MAX_NAME_LENGTH - 3] + "..."


def build_graph(tree: dict) -> "graphviz.Digraph":
    """
    Convert the nested tree dict into a Graphviz Digraph.
    Identical to Proto 1: depth-based 10-colour palette, white file fills,
    depth-coloured edges. No changes to this function from the original.
    """
    dot = graphviz.Digraph(name="FolderSco", comment="Generated by FolderSco 2.0")

    dot.attr(
        rankdir = GRAPH_RANKDIR,
        dpi     = GRAPH_DPI,
        bgcolor = "#F0F2F5",
        pad     = "0.5",
        nodesep = "0.3",
        ranksep = "0.6",
    )
    dot.attr("node",
        shape    = "box",
        style    = "filled,rounded",
        fontname = NODE_FONT,
        fontsize = NODE_FONTSIZE,
        margin   = "0.15,0.08",
    )
    dot.attr("edge",
        arrowsize = "0.7",
        penwidth  = "1.0",
    )

    id_counter = [0]

    def add_nodes(node: dict, parent_id, depth: int):
        node_id        = str(id_counter[0])
        id_counter[0] += 1
        label          = truncate(node["name"])
        palette        = DEPTH_COLORS[depth % len(DEPTH_COLORS)]

        if node["type"] == "dir":
            dot.node(node_id,
                label     = f"[D]  {label}",
                fillcolor = palette["fill"],
                fontcolor = palette["font"],
                color     = palette["border"],
                penwidth  = "1.8",
            )
        else:
            dot.node(node_id,
                label     = f"[F]  {label}",
                fillcolor = FILE_FILL,
                fontcolor = palette["font"],
                color     = palette["border"],
                penwidth  = "1.0",
            )

        if parent_id is not None:
            parent_palette = DEPTH_COLORS[(depth - 1) % len(DEPTH_COLORS)]
            dot.edge(parent_id, node_id,
                color    = parent_palette["border"],
                penwidth = "1.2",
            )

        for child in node.get("children", []):
            add_nodes(child, node_id, depth + 1)

    add_nodes(tree, None, 0)
    return dot


def render_graph(dot: "graphviz.Digraph", output_stem: Path, fmt: str) -> Path:
    """
    Render the Digraph to the chosen format and return the output Path.

    PNG / SVG / PDF — rendered via dot.exe (Graphviz must be on PATH).
    DOT             — saves the raw DOT source file; dot.exe not needed.
    """
    fmt_lower = fmt.lower()

    if fmt_lower == "dot":
        # Just write the DOT source — no rendering needed
        out_path = output_stem.parent / (output_stem.name + ".dot")
        out_path.write_text(dot.source, encoding="utf-8")
        return out_path

    # PNG / SVG / PDF rendered by Graphviz
    dot.render(
        filename = str(output_stem),
        format   = fmt_lower,
        engine   = "dot",
        cleanup  = True,   # Remove the intermediate .gv source file
    )
    return output_stem.parent / (output_stem.name + f".{fmt_lower}")


def check_graphviz_executable() -> bool:
    """Return True if dot.exe is on PATH, False otherwise."""
    try:
        graphviz.version()
        return True
    except graphviz.ExecutableNotFound:
        return False

# ============================================================
# 4. GUI — THEME CONSTANTS
# ============================================================

C_BG       = "#F5F6FA"   # Main window background
C_CARD     = "#FFFFFF"   # Card / panel background
C_ACCENT   = "#4A7FE5"   # Primary blue (header, generate button)
C_ACCHOV   = "#3A6FD5"   # Button hover blue
C_TEXT     = "#1F2937"   # Primary dark text
C_SUB      = "#6B7280"   # Secondary / label text
C_BORDER   = "#E5E7EB"   # Dividers and card borders
C_SUCCESS  = "#16A34A"   # Green for success
C_ERROR    = "#DC2626"   # Red for errors
FONT       = "Segoe UI"  # Windows-native UI font

# ============================================================
# 5. GUI APPLICATION CLASS
# ============================================================

class FolderScoApp:
    """
    Main GUI application.

    Layout (top-to-bottom):
        Header bar
        INPUT FOLDER  (entry + Browse)
        ── divider ──
        OUTPUT FORMAT (radio)  |  OUTPUT LOCATION (dir + filename)
        ── divider ──
        GENERATE button
        PROGRESS panel  (shown during generation)
        RESULTS panel   (shown on completion)
    """

    # ── Construction ─────────────────────────────────────────

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("FolderSco 2.0 — Folder Structure Visualizer")
        self.root.configure(bg=C_BG)
        self.root.resizable(True, True)
        self.root.minsize(720, 580)
        self.root.geometry("800x700")
        self._center_window()

        # Runtime state
        self._job_thread  = None
        self._job_state   = {}
        self._output_path = None

        # Tkinter variables
        self.folder_var   = tk.StringVar()
        self.outdir_var   = tk.StringVar(value=str(get_output_directory()))
        self.filename_var = tk.StringVar()
        self.autoname_var = tk.BooleanVar(value=True)
        self.format_var   = tk.StringVar(value="SVG")

        self._build_ui()

        # Check for dot.exe 200 ms after startup (non-blocking)
        self.root.after(200, self._check_graphviz_on_start)

    def _center_window(self):
        self.root.update_idletasks()
        w  = self.root.winfo_reqwidth()
        h  = self.root.winfo_reqheight()
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        self.root.geometry(f"+{(sw - w) // 2}+{(sh - h) // 2}")

    # ── UI Construction ───────────────────────────────────────

    def _build_ui(self):
        """Build every widget in the window."""

        # ── Header bar ────────────────────────────────────────
        hdr = tk.Frame(self.root, bg=C_ACCENT, height=56)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)

        tk.Label(hdr, text="🗂  FolderSco 2.0",
            font=(FONT, 15, "bold"), bg=C_ACCENT, fg="white"
        ).pack(side="left", padx=20, pady=12)

        tk.Label(hdr, text="Folder Structure Visualizer",
            font=(FONT, 10), bg=C_ACCENT, fg="#C7D9FF"
        ).pack(side="left", pady=16)

        # ── Scrollable body frame ─────────────────────────────
        body = tk.Frame(self.root, bg=C_BG)
        body.pack(fill="both", expand=True, padx=24, pady=16)

        # ── INPUT FOLDER ──────────────────────────────────────
        self._label(body, "INPUT FOLDER")

        inp = tk.Frame(body, bg=C_BG)
        inp.pack(fill="x", pady=(4, 0))

        # Path entry
        self.folder_entry = tk.Entry(inp,
            textvariable=self.folder_var,
            font=(FONT, 11),
            fg=C_SUB,
            relief="flat",
            bd=0,
            highlightthickness=1,
            highlightbackground=C_BORDER,
            highlightcolor=C_ACCENT,
        )
        self.folder_entry.pack(side="left", fill="x", expand=True, ipady=7)
        self._set_placeholder()
        self.folder_entry.bind("<FocusIn>",  self._clear_placeholder)
        self.folder_entry.bind("<FocusOut>", self._restore_placeholder)

        # Browse button
        tk.Button(inp, text="  Browse  ",
            font=(FONT, 10), bg=C_CARD, fg=C_TEXT,
            relief="flat", bd=0, cursor="hand2",
            highlightthickness=1, highlightbackground=C_BORDER,
            activebackground="#EEF2FF",
            command=self._browse_folder,
        ).pack(side="left", padx=(8, 0), ipady=7)

        # Drag-and-drop hint / setup
        if HAS_DND:
            tk.Label(body,
                text="✓ Drag & drop a folder onto the path field",
                font=(FONT, 8), bg=C_BG, fg=C_SUCCESS,
            ).pack(anchor="w", pady=(3, 0))
            self.folder_entry.drop_target_register(DND_FILES)
            self.folder_entry.dnd_bind("<<Drop>>", self._on_drop)
        else:
            tk.Label(body,
                text="Tip: pip install tkinterdnd2 to enable drag-and-drop",
                font=(FONT, 8), bg=C_BG, fg=C_SUB,
            ).pack(anchor="w", pady=(3, 0))

        self._divider(body)

        # ── OUTPUT FORMAT + LOCATION (side-by-side) ───────────
        cols = tk.Frame(body, bg=C_BG)
        cols.pack(fill="x", pady=(0, 4))
        cols.columnconfigure(0, weight=1)
        cols.columnconfigure(1, weight=2)

        # Left card: Format
        fmt_card = self._card(cols)
        fmt_card.grid(row=0, column=0, sticky="nsew", padx=(0, 8))

        self._card_label(fmt_card, "OUTPUT FORMAT")
        for fmt in ("SVG", "PNG", "PDF", "DOT"):
            ttk.Radiobutton(fmt_card, text=fmt,
                variable=self.format_var, value=fmt,
            ).pack(anchor="w", pady=3)

        tk.Label(fmt_card,
            text="SVG — vector, scalable\nPNG — raster image\nPDF — document\nDOT — Graphviz source",
            font=(FONT, 8), bg=C_CARD, fg=C_SUB, justify="left",
        ).pack(anchor="w", pady=(6, 0))

        # Right card: Location
        loc_card = self._card(cols)
        loc_card.grid(row=0, column=1, sticky="nsew")

        self._card_label(loc_card, "OUTPUT LOCATION")

        # Directory row
        dir_row = tk.Frame(loc_card, bg=C_CARD)
        dir_row.pack(fill="x", pady=(4, 0))

        tk.Entry(dir_row,
            textvariable=self.outdir_var,
            font=(FONT, 10), relief="flat", bd=0,
            highlightthickness=1,
            highlightbackground=C_BORDER,
            highlightcolor=C_ACCENT,
        ).pack(side="left", fill="x", expand=True, ipady=5)

        tk.Button(dir_row, text=" … ",
            font=(FONT, 10), bg=C_CARD, fg=C_TEXT,
            relief="flat", bd=0, cursor="hand2",
            highlightthickness=1, highlightbackground=C_BORDER,
            activebackground="#EEF2FF",
            command=self._browse_output,
        ).pack(side="left", padx=(6, 0), ipady=5)

        # Auto filename checkbox
        ttk.Checkbutton(loc_card,
            text="Auto-generate filename",
            variable=self.autoname_var,
            command=self._toggle_autoname,
        ).pack(anchor="w", pady=(8, 2))

        # Custom filename entry
        self.fname_entry = tk.Entry(loc_card,
            textvariable=self.filename_var,
            font=(FONT, 10), relief="flat", bd=0,
            state="disabled",
            highlightthickness=1,
            highlightbackground=C_BORDER,
            highlightcolor=C_ACCENT,
        )
        self.fname_entry.pack(fill="x", ipady=5)

        tk.Label(loc_card,
            text="e.g.  MyProject_report    (no extension needed)",
            font=(FONT, 8), bg=C_CARD, fg=C_SUB,
        ).pack(anchor="w", pady=(2, 0))

        self._divider(body)

        # ── GENERATE button ───────────────────────────────────
        self.gen_btn = tk.Button(body,
            text="⚡   GENERATE VISUALIZATION",
            font=(FONT, 13, "bold"),
            bg=C_ACCENT, fg="white",
            activebackground=C_ACCHOV, activeforeground="white",
            relief="flat", bd=0, cursor="hand2",
            pady=14,
            command=self._start_generation,
        )
        self.gen_btn.pack(fill="x", pady=(2, 8))
        self.gen_btn.bind("<Enter>", lambda e: self.gen_btn.config(bg=C_ACCHOV))
        self.gen_btn.bind("<Leave>", lambda e: self.gen_btn.config(bg=C_ACCENT))

        # ── PROGRESS panel (hidden until generation starts) ───
        self.prog_frame = tk.Frame(body, bg=C_CARD,
            relief="groove", bd=1)
        # Not packed yet

        tk.Label(self.prog_frame, text="PROGRESS",
            font=(FONT, 8, "bold"), bg=C_CARD, fg=C_SUB,
        ).pack(anchor="w", padx=14, pady=(10, 2))

        self.stage_lbl = tk.Label(self.prog_frame,
            text="Initializing...",
            font=(FONT, 11, "bold"), bg=C_CARD, fg=C_TEXT,
        )
        self.stage_lbl.pack(anchor="w", padx=14)

        # Stats grid inside progress frame
        stats = tk.Frame(self.prog_frame, bg=C_CARD)
        stats.pack(fill="x", padx=14, pady=(6, 0))

        self.lbl_files   = self._stat(stats, "Files scanned:",   "0", 0)
        self.lbl_folders = self._stat(stats, "Folders scanned:", "0", 1)
        self.lbl_elapsed = self._stat(stats, "Elapsed time:",    "00:00", 2)

        # Indeterminate progress bar (we cannot predict total count)
        self.pbar = ttk.Progressbar(self.prog_frame,
            mode="indeterminate", length=600)
        self.pbar.pack(fill="x", padx=14, pady=(8, 14))

        # ── RESULTS panel (hidden until generation completes) ─
        self.result_frame = tk.Frame(body, bg=C_CARD,
            relief="groove", bd=1)
        # Not packed yet

        self.res_icon = tk.Label(self.result_frame,
            font=(FONT, 30), bg=C_CARD)
        self.res_icon.pack(pady=(18, 4))

        self.res_title = tk.Label(self.result_frame,
            font=(FONT, 12, "bold"), bg=C_CARD)
        self.res_title.pack()

        self.res_detail = tk.Label(self.result_frame,
            font=(FONT, 9), bg=C_CARD, fg=C_SUB, justify="center")
        self.res_detail.pack(pady=(4, 10))

        res_btns = tk.Frame(self.result_frame, bg=C_CARD)
        res_btns.pack(pady=(0, 16))

        self.btn_open_file   = ttk.Button(res_btns, text="Open File",
            command=self._open_file)
        self.btn_open_folder = ttk.Button(res_btns, text="Open Folder",
            command=self._open_folder)
        self.btn_new_scan    = ttk.Button(res_btns, text="↺  New Scan",
            command=self._reset)

        for btn in (self.btn_open_file, self.btn_open_folder, self.btn_new_scan):
            btn.pack(side="left", padx=6)

    # ── Widget helpers ────────────────────────────────────────

    def _label(self, parent, text: str):
        """Section heading label."""
        tk.Label(parent, text=text,
            font=(FONT, 8, "bold"), bg=C_BG, fg=C_SUB,
        ).pack(anchor="w", pady=(6, 2))

    def _divider(self, parent):
        tk.Frame(parent, height=1, bg=C_BORDER).pack(fill="x", pady=12)

    def _card(self, parent) -> tk.Frame:
        return tk.Frame(parent, bg=C_CARD, relief="groove", bd=1,
                        padx=14, pady=12)

    def _card_label(self, parent, text: str):
        tk.Label(parent, text=text,
            font=(FONT, 8, "bold"), bg=C_CARD, fg=C_SUB,
        ).pack(anchor="w", pady=(0, 6))

    def _stat(self, parent, label: str, value: str, row: int) -> tk.Label:
        """Create a label/value pair in a grid and return the value label."""
        tk.Label(parent, text=label,
            font=(FONT, 10), bg=C_CARD, fg=C_SUB,
        ).grid(row=row, column=0, sticky="w", padx=(0, 16), pady=2)
        val = tk.Label(parent, text=value,
            font=(FONT, 10, "bold"), bg=C_CARD, fg=C_TEXT)
        val.grid(row=row, column=1, sticky="w", pady=2)
        return val

    # ── Placeholder helpers ───────────────────────────────────

    _PLACEHOLDER = "Paste a folder path, or click Browse…"

    def _set_placeholder(self):
        self.folder_entry.delete(0, "end")
        self.folder_entry.insert(0, self._PLACEHOLDER)
        self.folder_entry.config(fg=C_SUB)

    def _clear_placeholder(self, _event=None):
        if self.folder_var.get() == self._PLACEHOLDER:
            self.folder_entry.delete(0, "end")
            self.folder_entry.config(fg=C_TEXT)

    def _restore_placeholder(self, _event=None):
        if not self.folder_entry.get().strip():
            self._set_placeholder()

    # ── User interaction handlers ─────────────────────────────

    def _browse_folder(self):
        path = filedialog.askdirectory(title="Select Folder to Visualize")
        if path:
            self.folder_entry.delete(0, "end")
            self.folder_entry.insert(0, path)
            self.folder_entry.config(fg=C_TEXT)

    def _browse_output(self):
        path = filedialog.askdirectory(title="Select Output Directory")
        if path:
            self.outdir_var.set(path)

    def _on_drop(self, event):
        """Handle drag-and-drop onto the folder entry (tkinterdnd2)."""
        raw = event.data.strip()
        # Windows wraps paths with spaces in braces: {C:\My Folder}
        if raw.startswith("{") and raw.endswith("}"):
            raw = raw[1:-1]
        self.folder_entry.delete(0, "end")
        self.folder_entry.insert(0, raw)
        self.folder_entry.config(fg=C_TEXT)

    def _toggle_autoname(self):
        if self.autoname_var.get():
            self.fname_entry.config(state="disabled")
        else:
            self.fname_entry.config(state="normal")
            self.fname_entry.focus()

    def _check_graphviz_on_start(self):
        """Warn if dot.exe is missing, but do not block startup."""
        if not check_graphviz_executable():
            messagebox.showwarning(
                "Graphviz Not Found",
                "The Graphviz application (dot.exe) was not found on PATH.\n\n"
                "FolderSco needs the Graphviz executable to render PNG/SVG/PDF.\n"
                "(DOT format does not require dot.exe.)\n\n"
                "Install steps:\n"
                "  1. https://graphviz.org/download/ — download Windows installer\n"
                "  2. During setup, tick 'Add Graphviz to the system PATH'\n"
                "  3. Restart this application\n\n"
                "Verify installation with:  dot -V"
            )

    # ── Generation pipeline ───────────────────────────────────

    def _get_folder_path(self) -> str:
        raw = self.folder_entry.get().strip().strip('"').strip("'")
        return "" if raw == self._PLACEHOLDER else raw

    def _start_generation(self):
        """Validate inputs, then launch the background worker thread."""

        # ── Validate folder path ──────────────────────────────
        raw = self._get_folder_path()
        if not raw:
            messagebox.showwarning("No Folder Selected",
                "Please paste or browse to a folder path first.")
            return

        folder_path = Path(raw)
        if not folder_path.exists():
            messagebox.showerror("Path Not Found",
                f"The path does not exist:\n{folder_path}")
            return
        if not folder_path.is_dir():
            messagebox.showerror("Not a Folder",
                "The selected path is a file, not a folder.\n"
                "Please choose a directory.")
            return

        # ── Validate / create output directory ────────────────
        out_dir = Path(self.outdir_var.get().strip())
        try:
            out_dir.mkdir(parents=True, exist_ok=True)
        except Exception as exc:
            messagebox.showerror("Output Directory Error",
                f"Cannot create output directory:\n{exc}")
            return

        fmt = self.format_var.get()

        # For formats that need dot.exe, verify it is available
        if fmt != "DOT" and not check_graphviz_executable():
            messagebox.showerror("Graphviz Not Found",
                f"Rendering to {fmt} requires the Graphviz executable (dot.exe).\n\n"
                "Either install Graphviz and restart, or choose DOT format\n"
                "which saves the raw source file without requiring dot.exe.")
            return

        # ── Build output file stem ────────────────────────────
        # Drive roots (e.g. "C:\") have an empty .name — use drive letter instead.
        root_name = (
            folder_path.name
            or folder_path.drive.replace(":", "_Drive")
            or "output"
        )
        custom_name = "" if self.autoname_var.get() else self.filename_var.get()
        output_stem = build_output_stem(root_name, out_dir, fmt, custom_name)

        # ── UI: switch to "running" state ─────────────────────
        self.gen_btn.config(state="disabled",
            text="⏳   Generating…  please wait",
            bg="#8AAAE8")
        self.result_frame.pack_forget()
        self.prog_frame.pack(fill="x", pady=(0, 8))

        self.stage_lbl.config(text="Starting…", fg=C_TEXT)
        self.lbl_files.config(text="0")
        self.lbl_folders.config(text="0")
        self.lbl_elapsed.config(text="00:00")
        self.pbar.start(10)

        # ── Initialize shared job state ───────────────────────
        self._job_state = {
            "files":      0,
            "folders":    0,
            "stage":      "Starting…",
            "start_time": time.time(),
            "done":       False,
            "error":      None,
            "out_path":   None,
        }

        # ── Launch worker thread ──────────────────────────────
        self._job_thread = threading.Thread(
            target  = self._worker,
            args    = (folder_path, output_stem, fmt),
            daemon  = True,   # Dies with the process if the window is closed
        )
        self._job_thread.start()
        self._poll()   # Begin polling the shared state every 100 ms

    def _worker(self, folder_path: Path, output_stem: Path, fmt: str):
        """
        Runs in a background daemon thread.
        Writes only to self._job_state (dict) — never touches any tkinter widget.
        """
        state = self._job_state

        def on_progress(node_type: str):
            if node_type == "dir":
                state["folders"] += 1
            else:
                state["files"] += 1

        try:
            # Stage 1: Filesystem scan
            state["stage"] = "Scanning files…"
            tree = scan_directory(folder_path, on_progress=on_progress)

            # Stage 2: Build Graphviz graph
            state["stage"] = "Building graph…"
            dot_graph = build_graph(tree)

            # Stage 3: Render to chosen format
            state["stage"] = f"Rendering {fmt}…"
            out_path = render_graph(dot_graph, output_stem, fmt)

            state["out_path"] = out_path
            state["done"]     = True
            state["stage"]    = "Done"

        except graphviz.ExecutableNotFound:
            state["error"] = (
                "Graphviz executable (dot.exe) was not found.\n"
                "Install from https://graphviz.org/download/ and restart."
            )
        except RecursionError:
            state["error"] = (
                "The folder tree is too deeply nested for Python's recursion limit.\n"
                "Try a sub-folder instead of the root path."
            )
        except Exception as exc:
            state["error"] = str(exc)

    def _poll(self):
        """
        Called from the main thread every 100 ms.
        Reads _job_state (safe with the GIL for simple int/str reads),
        updates the UI, and re-schedules itself until the job finishes.
        """
        state   = self._job_state
        elapsed = time.time() - state["start_time"]
        mins    = int(elapsed) // 60
        secs    = int(elapsed) % 60

        self.stage_lbl.config(text=state["stage"])
        self.lbl_files.config(text=f"{state['files']:,}")
        self.lbl_folders.config(text=f"{state['folders']:,}")
        self.lbl_elapsed.config(text=f"{mins:02d}:{secs:02d}")

        if state["done"]:
            self._on_complete(state, elapsed)
        elif state["error"]:
            self._on_error(state["error"])
        else:
            # Not finished — poll again in 100 ms
            self.root.after(100, self._poll)

    def _on_complete(self, state: dict, elapsed: float):
        """Called on the main thread once the worker finishes successfully."""
        self.pbar.stop()
        self._output_path = state["out_path"]

        mins    = int(elapsed) // 60
        secs    = int(elapsed) % 60
        out_name = Path(state["out_path"]).name if state["out_path"] else "—"

        detail = (
            f"Files:      {state['files']:,}\n"
            f"Folders:    {state['folders']:,}\n"
            f"Time:       {mins:02d}:{secs:02d}\n"
            f"Output:     {out_name}"
        )

        self.res_icon.config(text="✓", fg=C_SUCCESS)
        self.res_title.config(
            text="Visualization generated successfully", fg=C_SUCCESS)
        self.res_detail.config(text=detail)

        # DOT format doesn't need dot.exe — hide Open File for DOT?
        # Actually opening a .dot file is fine — hide nothing.
        self.prog_frame.pack_forget()
        self.result_frame.pack(fill="x", pady=(0, 8))

        self.gen_btn.config(state="normal",
            text="⚡   GENERATE VISUALIZATION",
            bg=C_ACCENT)

    def _on_error(self, error_msg: str):
        """Called on the main thread if the worker encountered an error."""
        self.pbar.stop()

        self.res_icon.config(text="✗", fg=C_ERROR)
        self.res_title.config(text="Generation failed", fg=C_ERROR)
        self.res_detail.config(text=error_msg)

        self.prog_frame.pack_forget()
        self.result_frame.pack(fill="x", pady=(0, 8))

        self.gen_btn.config(state="normal",
            text="⚡   GENERATE VISUALIZATION",
            bg=C_ACCENT)

    # ── Post-generation actions ───────────────────────────────

    def _open_file(self):
        """Open the generated file with the system default application."""
        if self._output_path and Path(self._output_path).exists():
            os.startfile(str(self._output_path))
        else:
            messagebox.showwarning("File Not Found",
                "The output file could not be located.")

    def _open_folder(self):
        """Open the output directory in Windows Explorer."""
        if self._output_path:
            folder = Path(self._output_path).parent
            if folder.exists():
                os.startfile(str(folder))

    def _reset(self):
        """
        Clear the form and results so the user can immediately start
        a new scan. The generated file is NOT deleted — only the UI resets.
        """
        self.result_frame.pack_forget()
        self._output_path = None
        self._set_placeholder()
        self.filename_var.set("")
        # Reset output dir to default
        self.outdir_var.set(str(get_output_directory()))
        self.format_var.set("SVG")
        self.autoname_var.set(True)
        self.fname_entry.config(state="disabled")

# ============================================================
# 6. ENTRY POINT
# ============================================================

def main():
    if HAS_DND:
        root = TkinterDnD.Tk()
    else:
        root = tk.Tk()

    # Optional icon (suppress error if .ico not present)
    try:
        root.iconbitmap(str(Path(__file__).parent / "foldersco.ico"))
    except Exception:
        pass

    app = FolderScoApp(root)  # noqa: F841
    root.mainloop()


if __name__ == "__main__":
    main()
